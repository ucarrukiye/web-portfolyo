# Web Portfolyo

Kendi tanıtım sitem ve müşterilere gösterilecek örnek siteler. **Henüz canlıda değil.**

## İçerik

| Klasör | Ne? |
|---|---|
| `index.html` | Kendi tanıtım sitem (işler, paketler, süreç, WhatsApp butonu) |
| `ornekler/kafe/` | Fincan & Fırın — kafe örneği (menü sekmeleri, masa ayırtma) |
| `ornekler/kuafor/` | Atölye Makas — kuaför örneği (fiyat listesi, saat seçmeli randevu) |
| `ornekler/dis-klinigi/` | Lale Diş — diş kliniği örneği (tedaviler, hekimler, SSS, KVKK onaylı form) |
| `assets/` | Portfolyo kartlarındaki ekran görüntüleri |

Gerçek proje: **G.O Yapı** — https://www.goyapi.com.tr

## Ayarlar (tanıtım sitesi)

`index.html` dosyasının en altındaki `AYAR` bloğunu değiştir:

```js
const AYAR = {
  marka: "GO Yapı",           // marka adın
  whatsapp: "",               // 90 ile başlayan, boşluksuz numara (boşsa WhatsApp butonları gizlenir)
  fiyatlar: { tanitim: "", kurumsal: "", bakim: "" } // ör. "₺4.000"
};
```

## Görüntüleme

Dosyayı tarayıcıda açman yeterli (`index.html`). Kurulum gerekmez; tüm siteler tek HTML dosyası.

## Notlar

- Örnek sitelerdeki işletme adları, kişiler, fiyatlar ve yorumlar temsilidir; her sayfanın altında "örnek tasarım" notu var.
- Bir müşteri için uyarlarken: ad, renkler, metinler, WhatsApp numarası (`wa.me/...`) ve form gönderim adresi değiştirilir.
- Diş kliniği örneğinde sağlık reklam kurallarına uygun olsun diye fiyat, hasta yorumu ve "en iyi" gibi iddialar yok.
